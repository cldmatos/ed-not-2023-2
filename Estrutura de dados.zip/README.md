# ed-not-2023-2
Repositório da disciplina Estruturas de Dados, 2º semestre DSM noturno Fatec Franca 2023/2
